package com.mosquemanagementsystem.DaoImpl;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import com.Mosque_Management_System.Event;
import com.Mosque_Management_System.HibernateUtil;
import com.mosquemanagementsystem.Dao.EventDao;

public class EventDaoImpl implements EventDao {

    @Override
    public Event createEvent(Event event) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSession()) {
            tx = session.beginTransaction();
            session.save(event);
            tx.commit();
            return event;
        } catch (HibernateException e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Event> getAllEvent() {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSession()) {
            tx = session.beginTransaction();
            Query<Event> query = session.createQuery("from Event", Event.class);
            List<Event> events = query.list();
            tx.commit();
            return events;
        } catch (HibernateException e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Event getEvent(Long eventId) {
        try (Session session = HibernateUtil.getSession()) {
            return session.get(Event.class, eventId);
        } catch (HibernateException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public String deleteEvent(Long eventId) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSession()) {
            Event event = session.get(Event.class, eventId);
            if (event != null) {
                tx = session.beginTransaction();
                session.delete(event);
                tx.commit();
                return "Event deleted successfully";
            } else {
                return "Event not found";
            }
        } catch (HibernateException e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return "Error occurred while deleting event";
        }
    }

    @Override
    public Event updateEvent(Long eventId, Event updatedEvent) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSession()) {
            tx = session.beginTransaction();
            Event existingEvent = session.get(Event.class, eventId);
            if (existingEvent != null) {
                existingEvent.setEvent_type(updatedEvent.getEvent_type());
                existingEvent.setEventDate(updatedEvent.getEventDate());
                existingEvent.setEvent_Location(updatedEvent.getEvent_Location());
                session.update(existingEvent);
                tx.commit();
                return existingEvent;
            } else {
                tx.rollback();
                return null;
            }
        } catch (HibernateException e) {
            e.printStackTrace();
            if (tx != null) tx.rollback();
            return null;
        }
    }

	@Override
	public List<Event> getTeachersFromEvent() {
		// TODO Auto-generated method stub
		return null;
	}
}
