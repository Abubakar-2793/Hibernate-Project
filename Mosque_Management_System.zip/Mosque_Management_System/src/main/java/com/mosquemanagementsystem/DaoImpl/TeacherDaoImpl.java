package com.mosquemanagementsystem.DaoImpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.Mosque_Management_System.HibernateUtil;
import com.Mosque_Management_System.Teacher;
import com.mosquemanagementsystem.Dao.TeacherDao;
import com.mysql.cj.Query;

public class TeacherDaoImpl implements TeacherDao {

	@Override
	public Teacher createTeacher(Teacher teacher) {
		 Transaction tx = null;
	        try (Session session = HibernateUtil.getSession()) {
	            tx = session.beginTransaction();
	            session.save(teacher);
	            tx.commit();
	            return teacher;
	        } catch (HibernateException e) {
	            if (tx != null) tx.rollback();
	            e.printStackTrace();
	            return null;
	        }
	}

	@Override
	public List<Teacher> getAllTeacher() {
		Transaction transaction = null;
		List<Teacher> teachers = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			transaction = session.beginTransaction();
			teachers = session.createQuery("from Teacher", Teacher.class).getResultList();
			transaction.commit();
		} catch (HibernateException e) {
			if (transaction != null) {
				transaction.rollback();
			}
			System.err.println("Error retrieving teachers: " + e.getMessage());
		}
		return teachers;
	}

	@Override
	public Teacher getTeacher(Long teach_ID) {
		Transaction transaction = null;
		Teacher teacher = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			transaction = session.beginTransaction();
			teacher = session.get(Teacher.class, teach_ID);
			transaction.commit();
		} catch (HibernateException e) {
			if (transaction != null) {
				transaction.rollback();
			}
			System.err.println("Error retrieving teacher with ID " + teach_ID + ": " + e.getMessage());
		}
		return teacher;
	}

	@Override
	public Teacher updateTeacher(Long teach_ID, Teacher updatedTeacher) {
		Transaction transaction = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			transaction = session.beginTransaction();
			Teacher teacher = session.get(Teacher.class, teach_ID);
			if (teacher != null) {
				teacher.setTeach_Fname(updatedTeacher.getTeach_Fname());
				teacher.setTeach_Lname(updatedTeacher.getTeach_Lname());
				teacher.setEmail(updatedTeacher.getEmail());
				teacher.setPhone(updatedTeacher.getPhone());
				session.update(teacher);
				transaction.commit();
				return teacher;
			} else {
				System.out.println("Teacher with ID " + teach_ID + " not found.");
			}
		} catch (HibernateException e) {
			if (transaction != null) {
				transaction.rollback();
			}
			System.err.println("Error updating teacher with ID " + teach_ID + ": " + e.getMessage());
		}
		return null;
	}

	@Override
	public String deleteTeacher(Long teach_ID) {
		Transaction transaction = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			transaction = session.beginTransaction();
			Teacher teacher = session.get(Teacher.class, teach_ID);
			if (teacher != null) {
				session.delete(teacher);
				transaction.commit();
				return "Teacher deleted successfully.";
			} else {
				return "Teacher not found.";
			}
		} catch (HibernateException e) {
			if (transaction != null) {
				transaction.rollback();
			}
			System.err.println("Error deleting teacher with ID " + teach_ID + ": " + e.getMessage());
			return "Failed to delete teacher.";
		}
	}

	public List<Teacher> getTeachersFromEvent() {
	    Session session = HibernateUtil.getSessionFactory().openSession();
	    Transaction transaction = null;
	    List<Teacher> teachers = new ArrayList<>();
	    try {
	        transaction = session.beginTransaction();
	        org.hibernate.query.Query query = session.createQuery("SELECT DISTINCT e.teacher FROM Event e");
	        teachers = query.list();
	        transaction.commit();
	    } catch (HibernateException e) {
	        if (transaction != null) {
	            transaction.rollback();
	        }
	        e.printStackTrace();
	    } finally {
	        session.close();
	    }
	    return teachers;
	}

	public List<Teacher> getTeachersFromPrayer_Schedule() {
	    Session session = HibernateUtil.getSessionFactory().openSession();
	    Transaction transaction = null;
	    List<Teacher> teachers = new ArrayList<>();
	    try {
	        transaction = session.beginTransaction();
	        org.hibernate.query.Query query = session.createQuery("SELECT DISTINCT e.teacher FROM Prayer_Schedule e");
	        teachers = query.list();
	        transaction.commit();
	    } catch (HibernateException e) {
	        if (transaction != null) {
	            transaction.rollback();
	        }
	        e.printStackTrace();
	    } finally {
	        session.close();
	    }
	    return teachers;
	}
}
