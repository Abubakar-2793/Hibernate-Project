package com.mosquemanagementsystem.DaoImpl;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.Mosque_Management_System.Event;
import com.Mosque_Management_System.HibernateUtil;
import com.Mosque_Management_System.Prayer_Schedule;
import com.mosquemanagementsystem.Dao.*;

public class Prayer_ScheduleDaoImpl implements Prayer_ScheduleDao{

	@Override
	 public Prayer_Schedule createPrayer_Schedule(Prayer_Schedule prayerSchedule) {
        if (prayerSchedule == null) {
            throw new IllegalArgumentException("Prayer_Schedule cannot be null");
        }

        Transaction tx = null;
        try (Session session = HibernateUtil.getSession()) {
            tx = session.beginTransaction();
            session.save(prayerSchedule);
            tx.commit();
            return prayerSchedule;
        } catch (HibernateException e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return null;
        }
    }

	@Override
	public List<Prayer_Schedule> getAllPrayer_Schedule() {
	    Transaction tx = null;
	    List<Prayer_Schedule> prayerSchedules = new ArrayList<>();
	    try (Session session = HibernateUtil.getSession()) {
	        tx = session.beginTransaction();
	        Query<Prayer_Schedule> query = session.createQuery("FROM Prayer_Schedule", Prayer_Schedule.class);
	        prayerSchedules = query.getResultList();
	        tx.commit();
	    } catch (HibernateException e) {
	        if (tx != null) tx.rollback();
	        e.printStackTrace();
	    }
	    return prayerSchedules;
	}

	@Override
	public Prayer_Schedule getPrayer_Schedule(Long tID) {
		// TODO Auto-generated method stub
		 try (Session session = HibernateUtil.getSession()) {
	            return session.get(Prayer_Schedule.class, tID);
	        } catch (HibernateException e) {
	            e.printStackTrace();
	            return null;
	        }
	    }
	@Override
	public Prayer_Schedule updatePrayer_Schedule(Long tID, Prayer_Schedule updatedPrayer_Schedule) {
		// TODO Auto-generated method stub
		Transaction tx = null;
        try (Session session = HibernateUtil.getSession()) {
            tx = session.beginTransaction();
            Prayer_Schedule existingPrayer_Schedule = session.get(Prayer_Schedule.class, tID);
            if (existingPrayer_Schedule != null) {
            	/*existingPrayer_Schedule.setEvent_type(updatedEvent.getEvent_type());
            	existingPrayer_Schedule.setEventDate(updatedEvent.getEventDate());
            	session.update(existingPrayer_Schedule);
                tx.commit();*/
                return existingPrayer_Schedule;
            } else {
                tx.rollback();
                return null;
            }
        } catch (HibernateException e) {
            e.printStackTrace();
            if (tx != null) tx.rollback();
            return null;
        }
    }

	@Override
	public String deletePrayer_Schedule(Long id) {
		// TODO Auto-generated method stub
		 Transaction tx = null;
	        try (Session session = HibernateUtil.getSession()) {
	        	Prayer_Schedule prayer_Schedule = session.get(Prayer_Schedule.class, id);
	            if (prayer_Schedule != null) {
	                tx = session.beginTransaction();
	                session.delete(prayer_Schedule);
	                tx.commit();
	                return "prayer_Schedule deleted successfully";
	            } else {
	                return "prayer_Schedule not found";
	            }
	        } catch (HibernateException e) {
	            if (tx != null) tx.rollback();
	            e.printStackTrace();
	            return "Error occurred while deleting event";
	        }
	    }



}
