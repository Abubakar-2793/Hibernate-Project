package com.mosquemanagementsystem.DaoImpl;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import com.Mosque_Management_System.Donation;
import com.Mosque_Management_System.HibernateUtil;
import com.mosquemanagementsystem.Dao.DonationDao;

public class DonationDaoImpl implements DonationDao {

	public Donation createDonation(Donation donation) {
		 Transaction tx = null;
	        try (Session session = HibernateUtil.getSession()) {
	            tx = session.beginTransaction();
	            session.save(donation);
	            tx.commit();
	            return donation;
	        } catch (HibernateException e) {
	            if (tx != null) tx.rollback();
	            e.printStackTrace();
	            return null;
	        }
	}

    @Override
    public List<Donation> getAllDonations() {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSession()) {
            tx = session.beginTransaction();
            Query<Donation> query = session.createQuery("from Donation", Donation.class);
            List<Donation> donations = query.list();
            tx.commit();
            return donations;
        } catch (HibernateException e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Donation getDonation(Long donorId) {
        try (Session session = HibernateUtil.getSession()) {
            return session.get(Donation.class, donorId);
        } catch (HibernateException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Donation updateDonation(Long donorId, Donation updatedDonation) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSession()) {
            tx = session.beginTransaction();
            Donation existingDonation = session.get(Donation.class, donorId);
            if (existingDonation != null) {
                existingDonation.setDonar_name(updatedDonation.getDonar_name());
                existingDonation.setDon_type(updatedDonation.getDon_type());
                existingDonation.setDon_amount(updatedDonation.getDon_amount());
                existingDonation.setDon_date(updatedDonation.getDon_date());
                existingDonation.setPayment_method(updatedDonation.getPayment_method());
                session.update(existingDonation);
                tx.commit();
                return existingDonation;
            } else {
                tx.rollback();
                return null;
            }
        } catch (HibernateException e) {
            e.printStackTrace();
            if (tx != null) tx.rollback();
            return null;
        }
    }

    @Override
    public String deleteDonation(Long donorId) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSession()) {
            Donation donation = session.get(Donation.class, donorId);
            if (donation != null) {
                tx = session.beginTransaction();
                session.delete(donation);
                tx.commit();
                return "Donation deleted successfully";
            } else {
                return "Donation not found";
            }
        } catch (HibernateException e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return "Error occurred while deleting donation";
        }
    }
}
