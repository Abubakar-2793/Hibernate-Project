package com.mosquemanagementsystem.DaoImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import com.Mosque_Management_System.Event;
import com.Mosque_Management_System.Worshipper;
import com.mosquemanagementsystem.Dao.WorshipperDao;
import com.Mosque_Management_System.HibernateUtil;

public class WorshipperDaoImpl implements WorshipperDao {
	Scanner sc=new Scanner(System.in);

    @Override
    public Worshipper createWorshipper(Worshipper worshipper) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSession()) {
            tx = session.beginTransaction();
            session.save(worshipper);
            tx.commit();
            return worshipper;
        } catch (HibernateException e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Worshipper> getAllWorshipper() {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSession()) {
            tx = session.beginTransaction();
            Query<Worshipper> query = session.createQuery("from Worshipper", Worshipper.class);
            List<Worshipper> worshippers = query.list();
            tx.commit();
            return worshippers;
        } catch (HibernateException e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Worshipper updateWorshipper(Long Worp_ID, Worshipper updatedWorshipper) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSession()) {
            tx = session.beginTransaction();
            Worshipper existingWorshipper = session.get(Worshipper.class, Worp_ID);
            if (existingWorshipper != null) {
                existingWorshipper.setFirstName(updatedWorshipper.getFirstName());
                existingWorshipper.setLastName(updatedWorshipper.getLastName());
                existingWorshipper.setGender(updatedWorshipper.getGender());
                existingWorshipper.setEmail(updatedWorshipper.getEmail());
                existingWorshipper.setPhone(updatedWorshipper.getPhone());
                session.update(existingWorshipper);
                tx.commit();
                return existingWorshipper;
            } else {
                tx.rollback();
                return null;
            }
        } catch (HibernateException e) {
            e.printStackTrace();
            if (tx != null) tx.rollback();
            return null;
        }
    }

    @Override
    public String deleteWorshipper(Long worpId) {
    	String message=null;
		try(Session session=HibernateUtil.getSession()) {
			Worshipper wp1=session.get(Worshipper.class, worpId);
				session.beginTransaction();
				System.out.println("Are you sure  you want to delete?");
				String status=sc.next();
				if(status.equalsIgnoreCase("yes"))
				{
					session.delete(wp1);//data will be deleted from DB
					session.getTransaction().commit();
					session.evict(wp1);//data will remove from session Cache
					message="Object is deleted";
					
				}else
				{
					message="User wants to retain this object!!";
				}
				
		}
		catch (HibernateException e) {
			System.out.println(e);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		return message;
	}
	
    @Override
    public Worshipper getWorshipper(Long Worp_ID) {
        try (Session session = HibernateUtil.getSession()) {
            return session.get(Worshipper.class, Worp_ID);
        } catch (HibernateException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Event WorshipperEnrollment(Event enrollment) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSession()) {
            tx = session.beginTransaction();
            session.save(enrollment);
            tx.commit();
            return enrollment;
        } catch (HibernateException e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Event> getEnrollmentDetailsByEventId(String eventId) {
        try (Session session = HibernateUtil.getSession()) {
            Event course = session.get(Event.class, eventId);
            if (course != null) {
                Query<Event> query = session.createQuery("FROM Event WHERE course = :course");
                query.setParameter("course", course);
                return query.list();
            } else {
                throw new Exception("Course id is not found");
            }
        } catch (HibernateException e) {
            e.printStackTrace();
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<Worshipper> getWorshippersFromEvent() {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = null;
        List<Worshipper> teachers = new ArrayList<>();
        try {
            transaction = session.beginTransaction();
            Query query = session.createQuery("SELECT DISTINCT e.worshipper FROM Event e");
            teachers = query.list();
            transaction.commit();
        } catch (HibernateException e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }
        return teachers;
    }

	@Override
	public List<Worshipper> getWorshippersFromPrayer_Schedule() {
	    Session session = HibernateUtil.getSessionFactory().openSession();
	    Transaction transaction = null;
	    List<Worshipper> teachers = new ArrayList<>();
	    try {
	        transaction = session.beginTransaction();
	        Query query = session.createQuery("SELECT DISTINCT e.worshipper FROM Prayer_Schedule e");
	        teachers = query.list();
	        transaction.commit();
	    } catch (HibernateException e) {
	        if (transaction != null) {
	            transaction.rollback();
	        }
	        e.printStackTrace();
	    } finally {
	        session.close();
	    }
	    return teachers;
	}

	
}
