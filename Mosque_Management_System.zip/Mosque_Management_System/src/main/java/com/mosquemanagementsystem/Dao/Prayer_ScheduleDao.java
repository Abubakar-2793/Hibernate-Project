package com.mosquemanagementsystem.Dao;

import java.util.List;

import com.Mosque_Management_System.Prayer_Schedule;

public interface Prayer_ScheduleDao {

	Prayer_Schedule createPrayer_Schedule(Prayer_Schedule prayer_Schedule);

	List<Prayer_Schedule> getAllPrayer_Schedule();

	Prayer_Schedule getPrayer_Schedule(Long tID);

	Prayer_Schedule updatePrayer_Schedule(Long tID, Prayer_Schedule updatedPrayer_Schedule);

	String deletePrayer_Schedule(Long id);

}
