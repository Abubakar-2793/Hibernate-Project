package com.mosquemanagementsystem.Dao;

import java.util.List;
import com.Mosque_Management_System.Event;

public interface EventDao {
    Event createEvent(Event event);
    List<Event> getAllEvent();
    Event getEvent(Long eventId);
    String deleteEvent(Long eventId);
    Event updateEvent(Long eventId, Event updatedEvent);
	List<Event> getTeachersFromEvent();
}
