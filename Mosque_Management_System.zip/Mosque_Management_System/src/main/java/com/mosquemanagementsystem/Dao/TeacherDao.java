package com.mosquemanagementsystem.Dao;

import java.util.List;

import com.Mosque_Management_System.Prayer_Schedule;
import com.Mosque_Management_System.Teacher;

public interface TeacherDao {

	Teacher createTeacher(Teacher teach_ID);
	List<Teacher> getAllTeacher();
	Teacher getTeacher(Long teach_ID);
	Teacher updateTeacher(Long teach_ID, Teacher updatedTeacher);
	String deleteTeacher(Long teach_ID);
	List<Teacher> getTeachersFromEvent();
	List<Teacher> getTeachersFromPrayer_Schedule();

}
