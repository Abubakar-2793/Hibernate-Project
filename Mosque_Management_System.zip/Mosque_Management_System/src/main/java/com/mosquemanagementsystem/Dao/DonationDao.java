package com.mosquemanagementsystem.Dao;

import java.util.List;
import com.Mosque_Management_System.Donation;

public interface DonationDao {
    Donation createDonation(Donation donation);
    List<Donation> getAllDonations();
    Donation getDonation(Long donorId);
    Donation updateDonation(Long donorId, Donation updatedDonation);
    String deleteDonation(Long donorId);
}
