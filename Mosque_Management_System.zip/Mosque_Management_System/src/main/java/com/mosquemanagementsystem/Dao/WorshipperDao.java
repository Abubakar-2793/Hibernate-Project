package com.mosquemanagementsystem.Dao;

import java.util.List;
import com.Mosque_Management_System.Event;
import com.Mosque_Management_System.Worshipper;

public interface WorshipperDao {
    Worshipper createWorshipper(Worshipper worshipper);
    List<Worshipper> getAllWorshipper();
    Event WorshipperEnrollment(Event enrollment);
    List<Event> getEnrollmentDetailsByEventId(String eventId);
    Worshipper updateWorshipper(Long worpId, Worshipper updatedWorshipper);
    String deleteWorshipper(Long worpId);
    Worshipper getWorshipper(Long worpId);
	List<Worshipper> getWorshippersFromEvent();
	List<Worshipper> getWorshippersFromPrayer_Schedule();
}
 