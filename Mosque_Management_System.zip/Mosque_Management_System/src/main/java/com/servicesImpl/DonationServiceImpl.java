package com.servicesImpl;

import java.util.List;
import com.Mosque_Management_System.Donation;
import com.mosquemanagementsystem.Dao.DonationDao;
import com.mosquemanagementsystem.DaoImpl.DonationDaoImpl;
import com.services.DonationService;

public class DonationServiceImpl implements DonationService {
    private DonationDao donationDao = new DonationDaoImpl();

    @Override
    public Donation createDonation(Donation donation) {
        return donationDao.createDonation(donation);
    }

    @Override
    public List<Donation> getAllDonations() {
        return donationDao.getAllDonations();
    }

    @Override
    public Donation getDonation(Long donorId) {
        return donationDao.getDonation(donorId);
    }

    @Override
    public Donation updateDonation(Long donorId, Donation updatedDonation) {
        return donationDao.updateDonation(donorId, updatedDonation);
    }

    @Override
    public String deleteDonation(Long donorId) {
        return donationDao.deleteDonation(donorId);
    }

	@Override
	public Donation getDonation(long dn) {
		// TODO Auto-generated method stub
		return null;
	}
}
