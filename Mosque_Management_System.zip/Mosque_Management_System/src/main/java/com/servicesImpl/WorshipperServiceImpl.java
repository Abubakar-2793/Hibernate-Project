package com.servicesImpl;

import java.util.List;
import com.Mosque_Management_System.Event;
import com.Mosque_Management_System.Worshipper;
import com.mosquemanagementsystem.Dao.WorshipperDao;
import com.mosquemanagementsystem.DaoImpl.WorshipperDaoImpl;
import com.services.WorshipperService;

public class WorshipperServiceImpl implements WorshipperService {

    private WorshipperDao worshipperDao = new WorshipperDaoImpl();

    @Override
    public Worshipper createWorshipper(Worshipper worshipper) {
        return worshipperDao.createWorshipper(worshipper);
    }

    @Override
    public List<Worshipper> getAllWorshipper() {
        return worshipperDao.getAllWorshipper();
    }

    @Override
    public Event worshipperEnrollment(Event enrollment) {
        return worshipperDao.WorshipperEnrollment(enrollment);
    }

    @Override
    public List<Event> getEnrollmentDetailsByEventId(String eventId) {
        return worshipperDao.getEnrollmentDetailsByEventId(eventId);
    }

    @Override
    public Worshipper updateWorshipper(Long worpId, Worshipper updatedWorshipper) {
        return worshipperDao.updateWorshipper(worpId, updatedWorshipper);
    }

    @Override
    public String deleteWorshipper(Long worpId) {
        return worshipperDao.deleteWorshipper(worpId);
    }

    @Override
    public Worshipper getWorshipper(Long worpId) {
        return worshipperDao.getWorshipper(worpId);
    }

	@Override
	public List<Worshipper> getWorshippersFromEvent() {
		// TODO Auto-generated method stub
		return worshipperDao.getWorshippersFromEvent();
	}

	@Override
	public List<Worshipper> getWorshippersFromPrayer_Schedule() {
		// TODO Auto-generated method stub
		return worshipperDao.getWorshippersFromPrayer_Schedule();
	}

	

}
	

	

