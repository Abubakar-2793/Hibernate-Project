package com.servicesImpl;

import java.util.List;
import com.Mosque_Management_System.Teacher;
import com.services.TeacherService;
import com.mosquemanagementsystem.Dao.TeacherDao;
import com.mosquemanagementsystem.DaoImpl.TeacherDaoImpl;

public  class TeacherServiceImpl implements TeacherService {

    private TeacherDao teacherDao = new TeacherDaoImpl();

    @Override
    public Teacher createTeacher(Teacher teacher) {
        return teacherDao.createTeacher(teacher);
    }

    @Override
    public List<Teacher> getAllTeacher() {
        return teacherDao.getAllTeacher();
    }

    @Override
    public Teacher getTeacher(Long teach_ID) {
        return teacherDao.getTeacher(teach_ID);
    }

    @Override
    public Teacher updateTeacher(Long teach_ID, Teacher updatedTeacher) {
        return teacherDao.updateTeacher(teach_ID, updatedTeacher);
    }

    @Override
    public String deleteTeacher(Long teach_ID) {
        return teacherDao.deleteTeacher(teach_ID);
    }

	@Override
	public List<Teacher> getTeachersFromEvent() {
		// TODO Auto-generated method stub
		return teacherDao.getTeachersFromEvent();
	}

	@Override
	public List<Teacher> getTeachersFromPrayer_Schedule() {
		// TODO Auto-generated method stub
		return teacherDao.getTeachersFromPrayer_Schedule();
	}

	
}
