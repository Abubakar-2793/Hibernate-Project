package com.servicesImpl;

import java.util.List;
import com.Mosque_Management_System.Event;
import com.services.EventService;
import com.mosquemanagementsystem.Dao.EventDao;
import com.mosquemanagementsystem.DaoImpl.EventDaoImpl;

public class EventServiceImpl implements EventService {
    private EventDao eventDao = new EventDaoImpl();

    @Override
    public Event createEvent(Event event) {
        return eventDao.createEvent(event);
    }

    @Override
    public List<Event> getAllEvent() {
        return eventDao.getAllEvent();
    }

    @Override
    public Event getEvent(Long eventId) {
        return eventDao.getEvent(eventId);
    }

    @Override
    public Event updateEvent(Long eventId, Event updatedEvent) {
        return eventDao.updateEvent(eventId, updatedEvent);
    }

    @Override
    public String deleteEvent(Long eventId) {
        return eventDao.deleteEvent(eventId);
    }

	@Override
	public List<Event> getTeachersFromEvent() {
		// TODO Auto-generated method stub
		return eventDao.getTeachersFromEvent();
	}
}
