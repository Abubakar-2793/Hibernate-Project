package com.servicesImpl;
import java.util.List;

import com.Mosque_Management_System.Prayer_Schedule;
import com.services.*;
import com.mosquemanagementsystem.Dao.*;
import com.mosquemanagementsystem.DaoImpl.*;

public class Prayer_ScheduleServiceImpl implements Prayer_ScheduleService{

	private Prayer_ScheduleDao prayer_ScheduleDao=new Prayer_ScheduleDaoImpl();	
	@Override
	public Prayer_Schedule createPrayer_Schedule(Prayer_Schedule prayer_Schedule) {
		// TODO Auto-generated method stub
		return prayer_ScheduleDao.createPrayer_Schedule(prayer_Schedule);
	}

	@Override
	public List<Prayer_Schedule> getAllPrayer_Schedule() {
		// TODO Auto-generated method stub
		return prayer_ScheduleDao.getAllPrayer_Schedule();
	}

	@Override
	public Prayer_Schedule getPrayer_Schedule(Long tID) {
		// TODO Auto-generated method stub
		return prayer_ScheduleDao.getPrayer_Schedule(tID);
	}

	@Override
	public Prayer_Schedule updatePrayer_Schedule(Long tID, Prayer_Schedule updatedPrayer_Schedule) {
		// TODO Auto-generated method stub
		return prayer_ScheduleDao.updatePrayer_Schedule(tID,updatedPrayer_Schedule);
	}

	@Override
	public String deletePrayer_Schedulen(Long id) {
		// TODO Auto-generated method stub
		return prayer_ScheduleDao.deletePrayer_Schedule(id);
	}

}
