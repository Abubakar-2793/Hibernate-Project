package com.services;

import java.util.List;
import com.Mosque_Management_System.Event;
import com.Mosque_Management_System.Worshipper;

public interface WorshipperService {
    Worshipper createWorshipper(Worshipper worshipper);
    List<Worshipper> getAllWorshipper();
    Event worshipperEnrollment(Event enrollment);
    Worshipper getWorshipper(Long sId);
    List<Event> getEnrollmentDetailsByEventId(String eventId);
    Worshipper updateWorshipper(Long worpId, Worshipper updatedWorshipper);
    String deleteWorshipper(Long worpId);
	List<Worshipper> getWorshippersFromEvent();
	List<Worshipper> getWorshippersFromPrayer_Schedule();
}
