package com.services;

import java.util.List;

import com.Mosque_Management_System.Teacher;


public interface TeacherService {
	Teacher createTeacher(Teacher Teach_ID);
    List<Teacher> getAllTeacher();   
    Teacher getTeacher(Long Teach_ID);
    Teacher updateTeacher(Long Teach_ID, Teacher updatedTeacher);
    String deleteTeacher(Long Teach_ID);
	List<Teacher> getTeachersFromEvent();
	List<Teacher> getTeachersFromPrayer_Schedule();

}
