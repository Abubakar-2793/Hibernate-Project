package com.services;

import java.util.List;
import com.Mosque_Management_System.Event;

public interface EventService {
    Event createEvent(Event event);
    List<Event> getAllEvent();   
    Event getEvent(Long eventId);
    Event updateEvent(Long eventId, Event updatedEvent);
    String deleteEvent(Long eventId); // Corrected method name
	List<Event> getTeachersFromEvent();
}
