package com.services;

import java.util.List;
import com.Mosque_Management_System.Donation;

public interface DonationService {
    Donation createDonation(Donation donation);
    List<Donation> getAllDonations();   
    Donation getDonation(long dn);
    Donation updateDonation(Long donorId, Donation updatedDonation);
    String deleteDonation(Long donorId);
	Donation getDonation(Long donorId);
}
