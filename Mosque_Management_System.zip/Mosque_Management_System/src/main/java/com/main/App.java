package com.main;

/**
 * Hello world!
 *
 */
import java.time.LocalDate;
import java.time.LocalTime;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.Mosque_Management_System.Donation;
import com.Mosque_Management_System.Event;
import com.Mosque_Management_System.HibernateUtil;
import com.Mosque_Management_System.Prayer_Schedule;
import com.Mosque_Management_System.Teacher;
import com.Mosque_Management_System.Worshipper;
public class App {
public static void main(String[] args) {
// Obtain a Hibernate SessionFactory
SessionFactory factory = HibernateUtil.getSessionFactory();
// Create a new Student
LocalDate date1 = LocalDate.of(1988, 1, 13);
LocalTime time = LocalTime.parse("17:45:15"); // Parses the time string

//Ensure unique identifiers
Worshipper worshipper = new Worshipper( "Oliver", "Henry", date1, "M", "oliver@gmail.com", "6742906745");

//Create other entities with unique IDs
Teacher teacher = new Teacher("Lata", "Dongre", "lata@123gmail.com", null, worshipper); // Changed Teach_ID to avoid conflict

Donation donation=new Donation();
//Prayer_Schedule prayer=new Prayer_Schedule("Asr",time, worshipper, null);
Event event=new Event("Kabvali Activity",date1,"Local Mosque");
// Open a new session
Session session=factory.openSession();//Session session = factory.openSession();
// Begin a transaction
Transaction transaction = session.beginTransaction();
// Save the student to the database
session.save(worshipper);
session.save(teacher);
session.save(donation);
//session.save(prayer);
session.save(event);
// Commit the transaction
transaction.commit();
// Close the Session
session.close();
// Close the Session Factory
factory.close();
}
}
