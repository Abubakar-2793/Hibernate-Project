package com.Mosque_Management_System;

import java.util.List;



public interface WorshipperService {
	Worshipper createWorshipper(Worshipper wp1);
    List<Worshipper> getAllWorshipper();
    Event worshipperEnrollment(Event ev1);
    Worshipper getWorshipper(String worpId);
    List<Event> getWorshipperEventDetailsByEventId(String eventId);
    Worshipper updateWorshipper(String worpId, Worshipper updatedWorshipper);
    String deleteWorshipper(String worpId);

}
