package com.Mosque_Management_System;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Event {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Event_ID;

    @Column(length = 30, nullable = false)
    private String Event_type;

    @Column(nullable = false)
    private LocalDate EventDate;

    @Column(length = 30, nullable = false)
    private String Event_Location;

    // Default constructor
    public Event() {
        super();
    }
    @ManyToOne
    @JoinColumn(name = "Teacher_ID", nullable = false)
    private Teacher teacher;

    // Getters and setters for teacher
    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }
    @ManyToOne
    @JoinColumn(name = "Worp_ID", nullable = false)
    private Worshipper worshipper;

    // Getters and setters for worshipper
    public Worshipper getWorshipper() {
        return worshipper;
    }

    public void setWorshipper(Worshipper worshipper) {
        this.worshipper = worshipper;
    }
    public Event(String Event_type, LocalDate EventDate, String Event_Location, Teacher teacher, Worshipper worshipper) {
        this.Event_type = Event_type;
        this.EventDate = EventDate;
        this.Event_Location = Event_Location;
        this.teacher = teacher;
        this.worshipper = worshipper;
    }

    // Parameterized constructor
    public Event(String Event_type, LocalDate EventDate, String Event_Location) {
        this.Event_type = Event_type;
        this.EventDate = EventDate;
        this.Event_Location = Event_Location;
    }

    // Getters and setters
    public Long getEvent_ID() {
        return Event_ID;
    }

    public void setEvent_ID(Long Event_ID) {
        this.Event_ID = Event_ID;
    }

    public String getEvent_type() {
        return Event_type;
    }

    public void setEvent_type(String Event_type) {
        this.Event_type = Event_type;
    }

    public LocalDate getEventDate() {
        return EventDate;
    }

    public void setEventDate(LocalDate EventDate) {
        this.EventDate = EventDate;
    }

    public String getEvent_Location() {
        return Event_Location;
    }

    public void setEvent_Location(String Event_Location) {
        this.Event_Location = Event_Location;
    }

    @Override
    public String toString() {
        return "Event [Event_ID=" + Event_ID + ", Event_type=" + Event_type + ", EventDate=" + EventDate + ", Event_Location=" + Event_Location + ",Teacher="+teacher+",Worshipper="+worshipper+"]";
    }
}
