package com.Mosque_Management_System;

import java.time.LocalDate;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.Email;
import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
public class Worshipper {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Worp_ID")
    private Long Worp_ID;

    @NotBlank(message = "First Name is mandatory")
    @Size(max = 50, message = "First Name must be less than 50 characters")
    @Column(name = "FirstName", length = 50)
    private String firstName;

    @NotBlank(message = "Last Name is mandatory")
    @Size(max = 25, message = "Last Name must be less than 25 characters")
    @Column(name = "LastName", length = 25)
    private String lastName;

    @FutureOrPresent(message = "Date of Birth cannot be in the future")
    @Column(name = "DateOfBirth")
    private LocalDate dateOfBirth;

    @NotBlank(message = "Gender is mandatory")
    @Pattern(regexp = "Male|Female|Other", message = "Gender must be Male, Female, or Other")
    @Column(name = "Gender", length = 25)
    private String gender;

    @NotBlank(message = "Email is mandatory")
    @Email(message = "Email should be valid")
    @Size(max = 30, message = "Email must be less than 30 characters")
    @Column(name = "Email", length = 30)
    private String email;

    @NotBlank(message = "Phone is mandatory")
    @Pattern(regexp = "\\d{10,15}", message = "Phone must be between 10 and 15 digits")
    @Column(name = "Phone", length = 25)
    private String phone;

    @OneToMany(mappedBy = "worshipper")
    private List<Teacher> teachers;

    @OneToMany(mappedBy = "worshipper")
    private List<Prayer_Schedule> prayerSchedules;

    @OneToMany(mappedBy = "worshipper")
    private List<Donation> donations;

    @OneToMany(mappedBy = "worshipper")
    private List<Event> event;

    // Getters and Setters

    public Long getWorp_ID() {
        return Worp_ID;
    }

    public void setWorp_ID(Long worp_ID) {
        Worp_ID = worp_ID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public List<Teacher> getTeachers() {
        return teachers;
    }

    public void setTeachers(List<Teacher> teachers) {
        this.teachers = teachers;
    }

    public List<Prayer_Schedule> getPrayerSchedules() {
        return prayerSchedules;
    }

    public void setPrayerSchedules(List<Prayer_Schedule> prayerSchedules) {
        this.prayerSchedules = prayerSchedules;
    }

    public List<Donation> getDonations() {
        return donations;
    }

    public void setDonations(List<Donation> donations) {
        this.donations = donations;
    }

    public List<Event> getEvent() {
        return event;
    }

    public void setEvent(List<Event> event) {
        this.event = event;
    }

    // Constructors

    public Worshipper(String firstName, String lastName, LocalDate dateOfBirth, String gender, String email, String phone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
        this.email = email;
        this.phone = phone;
    }

    public Worshipper() {
    }

    @Override
    public String toString() {
        return "Worshipper [Worp_ID=" + Worp_ID + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth=" + dateOfBirth + ", gender=" + gender + ", email=" + email + ", phone=" + phone + "]";
    }
}
