package com.Mosque_Management_System;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Donation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Donor_ID")
    private long Donor_ID;

    @Column(length = 30, nullable = false)
    private String Donar_name;

    @Column(length = 30, nullable = false)
    private String Don_type;

    @Column(length = 30, nullable = false)
    private long Don_amount;

    @Column(length = 30)
    private LocalDate Don_date;

    @Column(length = 30, nullable = false)
    private String Payment_method;

    @ManyToOne
    @JoinColumn(name = "Worp_ID", nullable = false)
    private Worshipper worshipper;

    // Getters and Setters

    public long getDonor_ID() {
        return Donor_ID;
    }

    public void setDonor_ID(long donor_ID) {
        Donor_ID = donor_ID;
    }

    public String getDonar_name() {
        return Donar_name;
    }

    public void setDonar_name(String donar_name) {
        Donar_name = donar_name;
    }

    public String getDon_type() {
        return Don_type;
    }

    public void setDon_type(String don_type) {
        Don_type = don_type;
    }

    public long getDon_amount() {
        return Don_amount;
    }

    public void setDon_amount(long don_amount) {
        Don_amount = don_amount;
    }

    public LocalDate getDon_date() {
        return Don_date;
    }

    public void setDon_date(LocalDate don_date) {
        Don_date = don_date;
    }

    public String getPayment_method() {
        return Payment_method;
    }

    public void setPayment_method(String payment_method) {
        Payment_method = payment_method;
    }

    public Worshipper getWorshipper() {
        return worshipper;
    }

    public void setWorshipper(Worshipper worshipper) {
        this.worshipper = worshipper;
    }

    // Constructors

    public Donation(String Donar_name, String Don_type, long Don_amount, LocalDate Don_date, String Payment_method, Worshipper worshipper) {
        this.Donar_name = Donar_name;
        this.Don_type = Don_type;
        this.Don_amount = Don_amount;
        this.Don_date = Don_date;
        this.Payment_method = Payment_method;
        this.worshipper = worshipper;
    }

    public Donation() {
    }

    @Override
    public String toString() {
        return "Donation [Donor_ID="+Donor_ID+"Donar_name=" + Donar_name + ", Don_type=" + Don_type + ", Don_amount=" + Don_amount + ", Don_date=" + Don_date + ", Payment_method=" + Payment_method + ", worshipper=" + worshipper + "]";
    }
}
