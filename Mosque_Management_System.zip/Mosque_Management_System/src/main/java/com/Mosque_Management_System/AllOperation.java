package com.Mosque_Management_System;

import com.services.WorshipperService;
import com.services.TeacherService;
import com.services.EventService;
import com.services.DonationService;
import com.services.Prayer_ScheduleService;
import com.servicesImpl.WorshipperServiceImpl;

import com.servicesImpl.TeacherServiceImpl;
import com.servicesImpl.EventServiceImpl;
import com.servicesImpl.DonationServiceImpl;
import com.servicesImpl.Prayer_ScheduleServiceImpl;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

public class AllOperation {
    static Scanner sc = new Scanner(System.in);
    private static WorshipperService worshipperService = new WorshipperServiceImpl();
    private static TeacherService teacherservice = new TeacherServiceImpl();
    private static EventService eventService = new EventServiceImpl();
    private static DonationService donationService = new DonationServiceImpl();
    private static Prayer_ScheduleService prayer_Scheduleservice = new Prayer_ScheduleServiceImpl();

    // Method to get worshipper inputs
    public static Worshipper WorshipperInputs() {
      

        System.out.println("Enter First Name");
        String firstName = sc.nextLine();

        System.out.println("Enter Last Name");
        String lastName = sc.nextLine();

        System.out.println("Enter Date of Birth (yyyy-MM-dd)");
        String inputDate = sc.nextLine();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate DoB = null;

        try {
            DoB = LocalDate.parse(inputDate, formatter);
        } catch (DateTimeParseException e) {
            System.out.println("Invalid date format. Please enter the date in yyyy-MM-dd format.");
        }

        System.out.println("Enter Gender");
        String gender = sc.nextLine();

        System.out.println("Enter Email");
        String email = sc.nextLine();

        System.out.println("Enter Phone");
        String phone = sc.nextLine();

        return new Worshipper(firstName, lastName, DoB, gender, email, phone);
    }

    // Method to handle worshipper operations
    public static void WorshipperOperation() {
        while (true) {
        
            System.out.println("Press 1.Add Worshipper Details\nPress 2.Retrieve All Worshipper Data\n"
                    + "Press 3.Update Worshipper Data\nPress 4.Delete Worshipper Data\n"
                    + "Press 5.To View All Event Details\n"+ "Press 6.To View All Prayer Details\n"+ "Press 7.To get back to the main menu");
            System.out.println("*********************************");
            int input = sc.nextInt();
            sc.nextLine(); // Consume newline

            switch (input) {
                case 1:
                    Worshipper worshipper = WorshipperInputs();
                    Worshipper savedEntity = worshipperService.createWorshipper(worshipper);
                    System.out.println("Worshipper Data has been saved successfully: " + savedEntity);
                    break;

                case 2:
                    List<Worshipper> worshippers = worshipperService.getAllWorshipper();
                    for (Worshipper w : worshippers) {
                        System.out.println(w);
                    }
                    break;

                case 3:
                    System.out.println("Enter Worshipper Id to update the information");
                    Long sId = sc.nextLong();
                    sc.nextLine(); // Consume newline
                    Worshipper existingWorshipper = worshipperService.getWorshipper(sId);
                    if (existingWorshipper != null) {
                        Worshipper updatedWorshipper = WorshipperInputs();
                        Worshipper updatedInfo = worshipperService.updateWorshipper(sId, updatedWorshipper);
                        System.out.println("Worshipper Data has been updated Successfully: " + updatedInfo);
                    } else {
                        System.out.println("Worshipper Id not found");
                    }
                    break;

                case 4:
                    System.out.println("Enter Worshipper Id to delete the information");
                    Long id = sc.nextLong();
                    sc.nextLine(); // Consume newline
                    String message = worshipperService.deleteWorshipper(id);
                    System.out.println(message);
                    break;

                case 5:
                	System.out.println("View Event Details");
                	List<Event> ev = eventService.getAllEvent();
                    for (Event w : ev) {
                        System.out.println(w);
                    }
                    break;

                case 6:  
                	System.out.println("View All Prayer Details");
                	List<Prayer_Schedule> py = prayer_Scheduleservice.getAllPrayer_Schedule();
                    for (Prayer_Schedule w : py) {
                        System.out.println(w);
                    }
                    break;
                    
                case 7:
                	
                	MainOperation.mainOps();
                    return;

                default:
                    System.out.println("Invalid input. Please try again.");
            }
        }
    }

    // Method to get teacher inputs
    public static Teacher TeacherInputs() {
      

        System.out.println("Enter First Name");
        String Teach_Fname = sc.nextLine();

        System.out.println("Enter Last Name");
        String Teach_Lname = sc.nextLine();

        System.out.println("Enter Email");
        String email = sc.nextLine();

        System.out.println("Enter Phone");
        String phone = sc.nextLine();
        
        System.out.println("Enter Worshipper ID");
        Long worshipperId = sc.nextLong();
        sc.nextLine(); // Consume newline

        Worshipper worshipper = worshipperService.getWorshipper(worshipperId);
        
        if (worshipper == null) {
            System.out.println("Worshipper with ID " + worshipperId + " not found.");
            return null;
        }

        return new Teacher(Teach_Fname, Teach_Lname, email, phone, worshipper);
    }

    // Method to handle teacher operations
    public static void TeacherOperation() {
        while (true) {
      
            System.out.println("Press 1.Add Teacher Details\nPress 2.Retrieve All Teacher Data\n"
                    + "Press 3.Update Teacher Data\nPress 4.Delete Teacher Data\n"
                    + "Press 5.To View All Events\n"+ "Press 6.To View All Prayers\n"+ "Press 7.To retrive all Worshippers\n"+ "Press 8.To get back to the main menu");
            System.out.println("******************************");
            int input = sc.nextInt();
            sc.nextLine(); // Consume newline

            switch (input) {
                case 1:
                    Teacher teacher = TeacherInputs();
                    if (teacher != null) {
                        Teacher savedEntity = teacherservice.createTeacher(teacher);
                        System.out.println("Teacher Data has been saved successfully: " + savedEntity);
                    }
                    break;

                case 2:
                    List<Teacher> teachers = teacherservice.getAllTeacher();
                    for (Teacher t : teachers) {
                        System.out.println(t);
                    }
                    break;

                case 3:
                    System.out.println("Enter Teacher Id to update the information");
                    Long TID = sc.nextLong();
                    sc.nextLine(); // Consume newline
                    Teacher existingTeacher = teacherservice.getTeacher(TID);
                    if (existingTeacher != null) {
                        Teacher updatedTeacher = TeacherInputs();
                        if (updatedTeacher != null) {
                            Teacher updatedInfo = teacherservice.updateTeacher(TID, updatedTeacher);
                            System.out.println("Teacher Data has been updated Successfully: " + updatedInfo);
                        }
                    } else {
                        System.out.println("Teacher Id not found");
                    }
                    break;

                case 4:
                    System.out.println("Enter Teacher Id to delete the information");
                    Long id = sc.nextLong();
                    sc.nextLine(); // Consume newline
                    String message = teacherservice.deleteTeacher(id);
                    System.out.println(message);
                    break;

                case 5:
                	System.out.println("View All Events Details");
                	 List<Event> ev = eventService.getAllEvent();
                     for (Event t : ev) {
                         System.out.println(t);
                     }
                     break;
                   
                case 6: 
                	System.out.println("View All Prayer Details");
                	List<Prayer_Schedule> py = prayer_Scheduleservice.getAllPrayer_Schedule();
                    for (Prayer_Schedule t : py) {
                        System.out.println(t);
                    }
                    break;
                	 
                case 7:
                	System.out.println("View All Worshippers");
                	List<Worshipper> wp = worshipperService.getAllWorshipper();
                    for (Worshipper t : wp) {
                        System.out.println(t);
                    }
                    break;
                	
                case 8:
                	MainOperation.mainOps();
                    return;

                default:
                    System.out.println("Invalid input. Please try again.");
            }
        }
    }

    // Method to get event inputs
    public static Event EventInputs() {
     
        System.out.println("Enter Event_Type");
        String Event_type = sc.nextLine();

        System.out.println("Enter Event-Date (yyyy-MM-dd)");
        String inputDate = sc.nextLine();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate eventDate = null;

        try {
            eventDate = LocalDate.parse(inputDate, formatter);
        } catch (DateTimeParseException e) {
            System.out.println("Invalid date format. Please enter the date in yyyy-MM-dd format.");
        }

        System.out.println("Enter Event Location");
        String Event_Location = sc.nextLine();
       
        System.out.println("Enter Teacher ID: ");
        long TeacherID = sc.nextLong();

        Teacher teacher = teacherservice.getTeacher(TeacherID);
        if (teacher == null) {
            System.out.println("Teacher with ID " + TeacherID + " not found.");
            return null;
        }
        System.out.println("Enter Worshipper ID: ");
        long worshipperID = sc.nextLong();

        Worshipper worshipper = worshipperService.getWorshipper(worshipperID);
        if (worshipper == null) {
            System.out.println("Worshipper with ID " + worshipperID + " not found.");
            return null;
        }
        return new Event(Event_type, eventDate, Event_Location,teacher,worshipper);
    }

    // Method to handle event operations
    public static void EventOperation() {
        while (true) {
        	
            System.out.println("Press 1.Add Event Details\nPress 2.Retrieve All Event Data\n"
                    + "Press 3.Update Event Data\nPress 4.Delete Event Data\n"
                    + "Press 5.To get all teachers who are present in event\n"+ "Press 6.To all worshippers who are present in event\n"+ "Press 5.To get back to the main menu");
            System.out.println("****************************");
            int input = sc.nextInt();
            sc.nextLine(); // Consume newline

            switch (input) {
                case 1:
                    Event event = EventInputs();
                    Event savedEntity = eventService.createEvent(event);
                    System.out.println("Event Data has been saved successfully: " + savedEntity);
                    break;

                case 2:
                    List<Event> events = eventService.getAllEvent();
                    for (Event e : events) {
                        System.out.println(e);
                    }
                    break;

                case 3:
                    System.out.println("Enter Event Id to update the information");
                    Long TID = sc.nextLong();
                    sc.nextLine(); // Consume newline
                    Event existingEvent = eventService.getEvent(TID);
                    if (existingEvent != null) {
                        Event updatedEvent = EventInputs();
                        if (updatedEvent != null) {
                            Event updatedInfo = eventService.updateEvent(TID, updatedEvent);
                            System.out.println("Event Data has been updated Successfully: " + updatedInfo);
                        }
                    } else {
                        System.out.println("Event Id not found");
                    }
                    break;

                case 4:
                    System.out.println("Enter Event Id to delete the information");
                    Long id = sc.nextLong();
                    sc.nextLine(); // Consume newline
                    String message = eventService.deleteEvent(id);
                    System.out.println(message);
                    break;

                case 5:
                	 List<Teacher> teachers = teacherservice.getTeachersFromEvent();
                     for (Teacher e : teachers) {
                         System.out.println(e);
                     }
                     break;
                    
                case 6:
                	List<Worshipper> worshippers = worshipperService.getWorshippersFromEvent();
                    for (Worshipper e : worshippers) {
                        System.out.println(e);
                    }
                    break;
                case 7:
                	MainOperation.mainOps();
                    return;

                default:
                    System.out.println("Invalid input. Please try again.");
            }
        }
    }

    // Method to get donation inputs
    public static Donation DonationInputs() {
        Scanner sc=new Scanner(System.in);

    	System.out.println("Enter Donor Name");
        String donorName = sc.nextLine();

       
        

        System.out.println("Enter Donation Amount");
        long donationAmount = sc.nextLong();
       

        LocalDate donationDate = null;

        while (donationDate == null) {
            System.out.print("Enter the Donation Date (YYYY-MM-DD): ");
            Scanner sc1=new Scanner(System.in);
            String dateInput = sc1.nextLine();

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            try {
                donationDate = LocalDate.parse(dateInput, formatter);
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format. Please enter the date in yyyy-MM-dd format.");
            }
        }
        
        // Do something with donationDate
        System.out.println("Donation Date entered: " + donationDate);
            
            System.out.println("Enter Donation Type");
            Scanner sc1=new Scanner(System.in);
            String donationType = sc1.nextLine();    

        System.out.println("Enter Payment Method");
        String paymentMethod = sc1.nextLine();
        
        System.out.println("Enter Worshipper ID");
        Long worshipperId = sc1.nextLong();

        Worshipper worshipper = worshipperService.getWorshipper(worshipperId);
        
        if (worshipper == null) {
            System.out.println("Worshipper with ID " + worshipperId + " not found.");
            return null;
        }

        return new Donation(donorName, donationType, donationAmount, donationDate, paymentMethod, worshipper);
    }

    // Method to handle donation operations
    public static void DonationOperation() {
        while (true) {
        	
            System.out.println("Press 1.Add Donation Details\nPress 2.Retrieve All Donation Data\n"
                    + "Press 3.Update Donation Data\nPress 4.Delete Donation Data\n"
                    + "Press 5.To get back to the main menu");
            System.out.println("*******************************");
            int input = sc.nextInt();
         
            switch (input) {
                case 1:
                    Donation donation = DonationInputs();
                    if (donation != null) {
                        Donation savedEntity = donationService.createDonation(donation);
                        System.out.println("Donation Data has been saved successfully: " + savedEntity);
                    }
                    break;

                case 2:
                    List<Donation> donations = donationService.getAllDonations();
                    for (Donation d : donations) {
                        System.out.println(d);
                    }
                    break;

                case 3:
                    System.out.println("Enter Donor Id to update the information");
                    Long TID = sc.nextLong();
                    sc.nextLine(); // Consume newline
                    Donation existingDonation = donationService.getDonation(TID);
                    if (existingDonation != null) {
                        Donation updatedDonation = DonationInputs();
                        if (updatedDonation != null) {
                            Donation updatedInfo = donationService.updateDonation(TID, updatedDonation);
                            System.out.println("Donation Data has been updated Successfully: " + updatedInfo);
                        }
                    } else {
                        System.out.println("Donor Id not found");
                    }
                    break;

                case 4:
                    System.out.println("Enter Donor Id to delete the information");
                    Long id = sc.nextLong();
                    sc.nextLine(); // Consume newline
                    String message = donationService.deleteDonation(id);
                    System.out.println(message);
                    break;

                case 5:
                    MainOperation.mainOps();
                    return;

                default:
                    System.out.println("Invalid input. Please try again.");
            }
        }
    }

    public static Prayer_Schedule Prayer_ScheduleInputs() {
        System.out.println("Enter Prayer Type");
        String prayerType = sc.nextLine();

        LocalTime prayerTime = null;
        while (prayerTime == null) {
            System.out.print("Enter the prayer time (HH:mm): ");
            String timeInput = sc.nextLine();

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
            try {
                prayerTime = LocalTime.parse(timeInput, formatter);
            } catch (DateTimeParseException e) {
                System.out.println("Invalid time format. Please enter the time in HH:mm format.");
            }
        }

        System.out.println("Enter Teacher ID: ");
        long teacherID = sc.nextLong();
        sc.nextLine(); // Consume newline

        Teacher teacher = teacherservice.getTeacher(teacherID);
        if (teacher == null) {
            System.out.println("Teacher with ID " + teacherID + " not found.");
            return null;
        }

        
        System.out.println("Enter Worshipper ID: ");
        long worshipperID = sc.nextLong();

        Worshipper worshipper = worshipperService.getWorshipper(worshipperID);
        if (worshipper == null) {
            System.out.println("Worshipper with ID " + worshipperID + " not found.");
            return null;
        }

        return new Prayer_Schedule(prayerType, prayerTime, teacher, worshipper);
    }


    // Method to handle prayer schedule operations
    public static void Prayer_ScheduleOperation() {
        while (true) {
        	
            System.out.println("Press 1.Add Prayer_Schedule Details\nPress 2.Retrieve All Prayer_Schedule Data\n"
                    + "Press 3.Update Prayer_Schedule Data\nPress 4.Delete Prayer_Schedule Data\n"
                    + "Press 5.To get all teachers who are present in prayer\n"+ "Press 6.To get all worshippers who are present in prayer\n"+ "Press 7.To get back to the main menu");
            System.out.println("**************************************");
            int input = sc.nextInt();
            sc.nextLine(); // Consume newline
            switch (input) {
                case 1:
                    Prayer_Schedule prayerSchedule = Prayer_ScheduleInputs();
                    if (prayerSchedule != null) {
                        Prayer_Schedule savedEntity = prayer_Scheduleservice.createPrayer_Schedule(prayerSchedule);
                        System.out.println("Prayer Data has been saved successfully: " + savedEntity);
                       
                    }
                    break;

                case 2:
                    List<Prayer_Schedule> prayerSchedules = prayer_Scheduleservice.getAllPrayer_Schedule();
                    for (Prayer_Schedule ps : prayerSchedules) {
                        System.out.println(ps);
                    }
                    break;

                case 3:
                    System.out.println("Enter Prayer Id to update the information");
                    Long TID = sc.nextLong();
                    sc.nextLine(); // Consume newline
                    Prayer_Schedule existingPrayerSchedule = prayer_Scheduleservice.getPrayer_Schedule(TID);
                    if (existingPrayerSchedule != null) {
                        Prayer_Schedule updatedPrayerSchedule = Prayer_ScheduleInputs();
                        if (updatedPrayerSchedule != null) {
                            Prayer_Schedule updatedInfo = prayer_Scheduleservice.updatePrayer_Schedule(TID, updatedPrayerSchedule);
                            System.out.println("Prayer Data has been updated Successfully: " + updatedInfo);
                        }
                    } else {
                        System.out.println("Prayer Id not found");
                    }
                    break;

                case 4:
                    System.out.println("Enter Prayer Id to delete the information");
                    Long id = sc.nextLong();
                    sc.nextLine(); // Consume newline
                    String message = prayer_Scheduleservice.deletePrayer_Schedulen(id);
                    System.out.println(message);
                    break;

                case 5:
               	 List<Teacher> teachers = teacherservice.getTeachersFromPrayer_Schedule();
                    for (Teacher e : teachers) {
                        System.out.println(e);
                    }
                    break;
                   
               case 6:
               	List<Worshipper> worshippers = worshipperService.getWorshippersFromPrayer_Schedule();
                   for (Worshipper e : worshippers) {
                       System.out.println(e);
                   }
                   break;
               case 7:
               	MainOperation.mainOps();
                   return;

                default:
                    System.out.println("Invalid input. Please try again.");
            }
        }
    }
}
