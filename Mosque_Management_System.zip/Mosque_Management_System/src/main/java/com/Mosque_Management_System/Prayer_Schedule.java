package com.Mosque_Management_System;

import javax.persistence.*;
import java.time.LocalTime;
import java.util.Set;

@Entity
public class Prayer_Schedule {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(length = 10)
    private Long Prayer_ID;

    @Column(length = 30, nullable = false)
    private String Prayer_Type;

    @Column(nullable = false)
    private LocalTime Prayer_Time;

    @ManyToOne
    @JoinColumn(name = "Worp_ID", nullable = false)
    private Worshipper worshipper;

    @ManyToOne
    @JoinColumn(name = "teacher_id", nullable = false)
    private Teacher teacher;


    // Getters and Setters
    public Long getPrayer_ID() {
        return Prayer_ID;
    }

    public void setPrayer_ID(Long prayer_ID) {
        Prayer_ID = prayer_ID;
    }

    public String getPrayer_Type() {
        return Prayer_Type;
    }

    public void setPrayer_Type(String prayer_Type) {
        Prayer_Type = prayer_Type;
    }

    public LocalTime getPrayer_Time() {
        return Prayer_Time;
    }

    public void setPrayer_Time(LocalTime prayer_Time) {
        Prayer_Time = prayer_Time;
    }

    public Worshipper getWorshipper() {
        return worshipper;
    }

    public void setWorshipper(Worshipper worshipper) {
        this.worshipper = worshipper;
    }

    public Teacher getTeachers() {
        return teacher;
    }

    public void setTeachers(Teacher teachers) {
        this.teacher = teachers;
    }

    @Override
    public String toString() {
        return "Prayer_Schedule [Prayer_ID=" + Prayer_ID + ", Prayer_Type=" + Prayer_Type +
                ", Prayer_Time=" + Prayer_Time + ", worshipper=" + worshipper +
                ", teacher=" + teacher + "]";
    }

    // Constructors
    public Prayer_Schedule() {}

    public Prayer_Schedule(String Prayer_Type, LocalTime Prayer_Time, Teacher teacher,Worshipper worshipper) {
        this.Prayer_Type = Prayer_Type;
        this.Prayer_Time = Prayer_Time;
        this.teacher = teacher;
        this.worshipper=worshipper;
    }
}
