package com.Mosque_Management_System;

import javax.persistence.*;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

@Entity
public class Teacher implements Set<Teacher> {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(length = 10, nullable = false)
    private Long Teach_ID;

    @Column(length = 30, nullable = false)
    private String Teach_Fname;

    @Column(length = 30, nullable = false)
    private String Teach_Lname;

    @Column(length = 30, nullable = false)
    private String email;
    
    @Column(length = 30, nullable = false)
    private String phone;

    @ManyToOne
    @JoinColumn(name = "Worp_ID", nullable = false)
    private Worshipper worshipper;

    @OneToMany(mappedBy = "teacher")
    private Set<Prayer_Schedule> prayerSchedules = new HashSet<>();
    // Getters and Setters
    public Long getTeach_ID() {
        return Teach_ID;
    }

    public void setTeach_ID(Long teach_ID) {
        Teach_ID = teach_ID;
    }

    public String getTeach_Fname() {
        return Teach_Fname;
    }

    public void setTeach_Fname(String teach_Fname) {
        Teach_Fname = teach_Fname;
    }

    public String getTeach_Lname() {
        return Teach_Lname;
    }

    public void setTeach_Lname(String teach_Lname) {
        Teach_Lname = teach_Lname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Worshipper getWorshipper() {
        return worshipper;
    }

    public void setWorshipper(Worshipper worshipper) {
        this.worshipper = worshipper;
    }

    public Set<Prayer_Schedule> getPrayerSchedules() {
        return prayerSchedules;
    }

    public void setPrayerSchedules(Set<Prayer_Schedule> prayerSchedules) {
        this.prayerSchedules = prayerSchedules;
    }

    @Override
    public String toString() {
        return "Teacher [Teach_ID=" + Teach_ID + ", Teach_Fname=" + Teach_Fname +
                ", Teach_Lname=" + Teach_Lname + ", email=" + email + ", phone=" + phone +
                ", worshipper=" + worshipper + "]";
    }

    // Constructors
    public Teacher(String Teach_Fname, String Teach_Lname, String email, String phone, Worshipper worshipper) {
        this.Teach_Fname = Teach_Fname;
        this.Teach_Lname = Teach_Lname;
        this.email = email;
        this.phone = phone;
        this.worshipper = worshipper;
    }

    public Teacher() {
        super();
    }

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean contains(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterator<Teacher> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object[] toArray() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> T[] toArray(T[] a) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean add(Teacher e) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean remove(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean addAll(Collection<? extends Teacher> c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean retainAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}
}
