package com.Mosque_Management_System;
import java.util.Scanner;

public class MainOperation {

	static Scanner sc=new Scanner(System.in);

	public static void mainOps()
	{
		while(true) {
			System.out.println("\n================ Mosque Manaement System =======================");
		System.out.println("Press 1.Worshipper Details\nPress 2.Teacher Deatils"
				+ "\nPress 3.Event Details\nPress 4. Donation Details\n"
				+ "Press 5.Prayer_Schedule Details\nPress 6.Quit"
				);
		System.out.println("===============================================================");
		int input=sc.nextInt();

		switch(input)
		{
			case 1:
				System.out.println("*********** Worshipper Details ************");
				AllOperation.WorshipperOperation();
				
				break;
		          
			case 2:
				System.out.println("*********** Teacher Details ************");
				AllOperation.TeacherOperation();
			
				break;
				
			case 3:
				System.out.println("*********** Event Details ************");
				AllOperation.EventOperation();
				
				break;
				
			case 4:
				System.out.println("*********** Donation Details ************");
				AllOperation.DonationOperation();
				

				break;
			case 5:
				System.out.println("*********** Prayer_Schedule Details ************");
				AllOperation.Prayer_ScheduleOperation();
			

				break;
				
			case 6:System.exit(0);
				default:
					System.out.println("wrong input");
		}
		
		}

	}

	public static void main(String[] args)
	{
		
		mainOps();

	}
	}
